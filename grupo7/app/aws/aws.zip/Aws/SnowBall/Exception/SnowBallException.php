<?php
namespace Aws\SnowBall\Exception;

use Aws\Exception\AwsException;

/**
 * Represents an error interacting with the **Amazon Import/Export Snowball** service.
 */
class SnowBallException extends AwsException {}
