<?php
// This file was auto-generated from sdk-root/src/data/codestar-notifications/2019-10-15/paginators-1.json
return [ 'pagination' => [ 'ListEventTypes' => [ 'input_token' => 'NextToken', 'limit_key' => 'MaxResults', 'output_token' => 'NextToken', 'result_key' => 'EventTypes', ], 'ListNotificationRules' => [ 'input_token' => 'NextToken', 'limit_key' => 'MaxResults', 'output_token' => 'NextToken', 'result_key' => 'NotificationRules', ], 'ListTargets' => [ 'input_token' => 'NextToken', 'limit_key' => 'MaxResults', 'output_token' => 'NextToken', 'result_key' => 'Targets', ], ],];
